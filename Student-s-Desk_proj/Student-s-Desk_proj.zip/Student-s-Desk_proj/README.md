# Student-s-Desk
JAVA group project

# Update Existing Git Repo
Open Student-s-Desk in terminal/cmd

type : git pull origin main

# Upload your work

0 >>> git status

1 >>> git add .

2 >>> git commit -m "comment"

3 >>> git push origin main
