package src.administration;

import javax.swing.*;
import java.time.LocalDate;
import java.time.Period;
import java.util.Date;
import java.util.Scanner;

public class Faculty {
    private String name;
    private String designation;
    private String ID;
    private LocalDate dob;
    private String email_id;
    private String gender;
    private int age;
    private String address;
    private int phone_number1;
    private int addhar_number;
    private int salary ;

    Faculty()
    {

    }

    Faculty(String name , String designation , String ID ,LocalDate dob , String email_id , String gender ,  String  address , int phone_number1 , int addhar_number , int salary)
    {
        this.name = name;
        this.designation = designation ;
        this.ID = ID;
        this.dob = dob;
        this.email_id = email_id;
        this.gender = gender;
        this.age = calculateAge(dob);
        this.address = address;
        this.phone_number1 = phone_number1;
        this.addhar_number = addhar_number;
        this.salary = salary;

    }


    public void DateToLocalDate()
    {
        Date date = new java.util.Date();
        LocalDate localDate = new java.sql.Date(date.getTime()).toLocalDate();
    }

    public int calculateAge(LocalDate d)
    {
        LocalDate dt = d;
        LocalDate curDate = LocalDate.now();
        if ((dt != null) && (curDate != null))
        {
            return Period.between(dt,curDate).getYears();
        }
        else
        {
            return 0;
        }

    }

    public int getPhone_number1() {
        return phone_number1;
    }

    public int getAddhar_number() {
        return addhar_number;
    }

    public String getAddress() {
        return address;
    }

    public int getAge() {
        return age;
    }

    public String getName() {
        return name;
    }

    public String getID() {
        return ID;
    }

    public String getEmail_id() {
        return email_id;
    }

    public String getGender() {
        return gender;
    }

    public LocalDate getDob() {
        return dob;
    }

    public String getDesignation() {
        return designation;
    }

    public void setPhone_number1(int phone_number1) {
        this.phone_number1 = phone_number1;
    }

    public void setAddhar_number(int addhar_number) {
        this.addhar_number = addhar_number;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public void setEmail_id(String email_id) {
        this.email_id = email_id;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public void Update_Right_Faculty(int ID)
    {

        Scanner scan = new Scanner(System.in);
        String option;
        System.out.print("Do you want to update your Addhar number (y/n) : ");
        option = scan.nextLine();
        if(option.compareTo("y") == 0)
        {
            System.out.print("Enter your new addhar number : ");
            this.addhar_number = scan.nextInt();
        }
        System.out.println("Do you want to update your phone number (y/n) : ");
        option = scan.nextLine();
        if(option.compareTo("y") == 0)
        {
            System.out.print("Enter your new phone number : ");
            this.phone_number1 = scan.nextInt();
        }
        System.out.println("Do you want to update your address (y/n) : ");
        option = scan.nextLine();
        if(option.compareTo("y") == 0)
        {
            System.out.print("Enter your new address : ");
            this.address = scan.nextLine();

        }

    }


}
