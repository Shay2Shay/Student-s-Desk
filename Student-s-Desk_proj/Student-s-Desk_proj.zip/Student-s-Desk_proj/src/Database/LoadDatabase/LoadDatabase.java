package src.Database.LoadDatabase;

public interface LoadDatabase {
    // public void loadCsv(String name);
    public void loadCsv(String name, String path);
    // public void viewDatabase(String table);

    
}
