package src.Example;

public class Main2 {
    // public static void main(String[] args) {
    //     yoyo();
    // }

    public static void yoyo(){
        System.out.println("YOYO");
    }
}
